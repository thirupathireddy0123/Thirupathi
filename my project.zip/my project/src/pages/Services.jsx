import {
  Box,
  Container,
  Typography,
  Grid,
  Card,
  CardContent,
  Chip
} from "@mui/material";

import CodeIcon from "@mui/icons-material/Code";
import StorageIcon from "@mui/icons-material/Storage";
import CampaignIcon from "@mui/icons-material/Campaign";

export default function Services() {
  return (
    <Box id="services">

      {/* Hero Section */}

      <Box
        sx={{
          background: "linear-gradient(135deg,#eef2ff,#e3f2fd)",
          py: 10,
          textAlign: "center"
        }}
      >
        <Typography variant="h3" sx={{ fontWeight: "bold" }}>
          Our Professional Services
        </Typography>

        <Typography sx={{ mt: 2, color: "#555" }}>
          We provide end-to-end digital solutions for startups and enterprises.
        </Typography>
      </Box>

      {/* Services Cards */}

      <Container maxWidth="lg" sx={{ py: 10 }}>

        <Grid container spacing={4}>

          <ServiceCard
            icon={<CodeIcon sx={{ fontSize: 50, color: "#1976d2" }} />}
            title="Frontend Development"
            desc="Modern responsive web applications using React.js and Material UI."
          />

          <ServiceCard
            icon={<StorageIcon sx={{ fontSize: 50, color: "#2e7d32" }} />}
            title="Backend Development"
            desc="Scalable backend APIs and cloud infrastructure."
          />

          <ServiceCard
            icon={<CampaignIcon sx={{ fontSize: 50, color: "#ed6c02" }} />}
            title="Digital Marketing"
            desc="SEO, social media marketing, and growth strategies."
          />

        </Grid>

      </Container>

      {/* Technology Stack */}

      <Box sx={{ background: "#f8fafc", py: 10 }}>

        <Container maxWidth="lg">

          <Typography
            variant="h4"
            sx={{ textAlign: "center", mb: 6, fontWeight: "bold" }}
          >
            Technologies We Use
          </Typography>

          <Box
            sx={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "center",
              gap: 2
            }}
          >

            <Chip label="React.js" color="primary" />
            <Chip label="Node.js" color="success" />
            <Chip label="Java" color="warning" />
            <Chip label="Spring Boot" color="secondary" />
            <Chip label="AWS" color="primary" />
            <Chip label="MongoDB" color="success" />
            <Chip label="Docker" color="warning" />

          </Box>

        </Container>

      </Box>

      {/* Process Section */}

      <Container maxWidth="lg" sx={{ py: 10 }}>

        <Typography
          variant="h4"
          sx={{ textAlign: "center", mb: 6, fontWeight: "bold" }}
        >
          Our Work Process
        </Typography>

        <Grid container spacing={4}>

          <ProcessStep number="01" title="Planning" />
          <ProcessStep number="02" title="Design" />
          <ProcessStep number="03" title="Development" />
          <ProcessStep number="04" title="Launch" />

        </Grid>

      </Container>

    </Box>
  );
}

/* Service Card Component */

function ServiceCard({ icon, title, desc }) {
  return (
    <Grid item xs={12} md={4}>
      <Card
        sx={{
          p: 4,
          textAlign: "center",
          borderRadius: "16px",
          transition: "0.3s",
          "&:hover": {
            transform: "translateY(-10px)",
            boxShadow: "0 15px 35px rgba(0,0,0,0.1)"
          }
        }}
      >
        {icon}

        <CardContent>

          <Typography variant="h5" sx={{ mt: 2 }}>
            {title}
          </Typography>

          <Typography sx={{ mt: 2, color: "#555" }}>
            {desc}
          </Typography>

        </CardContent>
      </Card>
    </Grid>
  );
}

/* Process Component */

function ProcessStep({ number, title }) {
  return (
    <Grid item xs={12} md={3}>

      <Box sx={{ textAlign: "center" }}>

        <Typography
          variant="h3"
          sx={{ fontWeight: "bold", color: "#1976d2" }}
        >
          {number}
        </Typography>

        <Typography variant="h6">
          {title}
        </Typography>

      </Box>

    </Grid>
  );
}