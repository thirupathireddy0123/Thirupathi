import {
  Box,
  Container,
  Typography,
  Grid,
  TextField,
  Button,
  Card,
  CardContent
} from "@mui/material";

import EmailIcon from "@mui/icons-material/Email";
import PhoneIcon from "@mui/icons-material/Phone";
import LocationOnIcon from "@mui/icons-material/LocationOn";

export default function Contact() {
  return (
    <Box id="contact">

      {/* Hero Section */}

      <Box
        sx={{
          background: "linear-gradient(135deg,#eef2ff,#e3f2fd)",
          py: 10,
          textAlign: "center"
        }}
      >
        <Typography variant="h3" sx={{ fontWeight: "bold" }}>
          Contact Our Team
        </Typography>

        <Typography sx={{ mt: 2, color: "#555" }}>
          We'd love to hear from you. Get in touch with us.
        </Typography>
      </Box>

      {/* Contact Section */}

      <Container maxWidth="lg" sx={{ py: 10 }}>

        <Grid container spacing={6}>

          {/* Contact Form */}

          <Grid item xs={12} md={7}>

            <Typography variant="h5" sx={{ mb: 3 }}>
              Send us a message
            </Typography>

            <TextField
              fullWidth
              label="Your Name"
              sx={{ mb: 3 }}
            />

            <TextField
              fullWidth
              label="Email Address"
              sx={{ mb: 3 }}
            />

            <TextField
              fullWidth
              label="Message"
              multiline
              rows={5}
              sx={{ mb: 3 }}
            />

            <Button
              variant="contained"
              sx={{
                px: 4,
                py: 1.5,
                borderRadius: "25px"
              }}
            >
              Send Message
            </Button>

          </Grid>

          {/* Contact Info */}

          <Grid item xs={12} md={5}>

            <Card sx={{ p: 3, mb: 3 }}>
              <CardContent sx={{ display: "flex", gap: 2 }}>
                <EmailIcon color="primary" />
                <Box>
                  <Typography variant="h6">Email</Typography>
                  <Typography>contact@mystartup.com</Typography>
                </Box>
              </CardContent>
            </Card>

            <Card sx={{ p: 3, mb: 3 }}>
              <CardContent sx={{ display: "flex", gap: 2 }}>
                <PhoneIcon color="primary" />
                <Box>
                  <Typography variant="h6">Phone</Typography>
                  <Typography>+91 9876543210</Typography>
                </Box>
              </CardContent>
            </Card>

            <Card sx={{ p: 3 }}>
              <CardContent sx={{ display: "flex", gap: 2 }}>
                <LocationOnIcon color="primary" />
                <Box>
                  <Typography variant="h6">Office</Typography>
                  <Typography>Hyderabad, India</Typography>
                </Box>
              </CardContent>
            </Card>

          </Grid>

        </Grid>

      </Container>

    </Box>
  );
}