import { Box, Typography, Button, Container, Grid } from "@mui/material";

export default function Home() {
  return (
    <Box id="home"
      sx={{
        background: "linear-gradient(135deg,#f5f7fa,#e3f2fd)",
        minHeight: "80vh",
        display: "flex",
        alignItems: "center"
      }}
    >
      <Container maxWidth="lg">

        <Grid container spacing={6} alignItems="center">

          {/* Left Content */}

          <Grid item xs={12} md={6}>

            <Typography
              variant="h2"
              sx={{
                fontWeight: "bold",
                lineHeight: 1.2
              }}
            >
              Build Powerful
              <span style={{ color: "#1976d2" }}>
                {" "}Digital Products
              </span>
            </Typography>

            <Typography
              variant="h6"
              sx={{
                mt: 3,
                color: "#555"
              }}
            >
              We help businesses grow with modern
              frontend development, backend systems
              and digital marketing solutions.
            </Typography>

            {/* Buttons */}

            <Box sx={{ mt: 4, display: "flex", gap: 2 }}>

              <Button
                variant="contained"
                sx={{
                  px: 4,
                  py: 1.5,
                  borderRadius: "25px",
                  background:
                    "linear-gradient(45deg,#1976d2,#42a5f5)"
                }}
              >
                Get Started
              </Button>

              <Button
                variant="outlined"
                sx={{
                  px: 4,
                  py: 1.5,
                  borderRadius: "25px"
                }}
              >
                View Services
              </Button>

            </Box>

          </Grid>

          {/* Right Image */}

          <Grid item xs={12} md={6}>

            <img
              src="https://illustrations.popsy.co/gray/web-design.svg"
              alt="startup"
              style={{
                width: "100%",
                maxWidth: "500px"
              }}
            />

          </Grid>

        </Grid>

      </Container>
    </Box>
  );
}