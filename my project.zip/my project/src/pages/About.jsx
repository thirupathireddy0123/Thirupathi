import { Box, Container, Typography, Grid } from "@mui/material";

export default function About() {
  return (
    <Box id="about">

      <Box sx={{ py: 10, background: "#f8fafc" }}>
        <Container maxWidth="lg">

          <Grid container spacing={6} alignItems="center">

            {/* Image Section */}
            <Grid item xs={12} md={6}>
              <img
                src="https://illustrations.popsy.co/gray/team-work.svg"
                alt="about company"
                style={{ width: "100%", maxWidth: "500px" }}
              />
            </Grid>

            {/* Text Section */}
            <Grid item xs={12} md={6}>

              <Typography
                variant="h3"
                sx={{ fontWeight: "bold", mb: 3 }}
              >
                About Our Company
              </Typography>

              <Typography sx={{ color: "#555", mb: 3 }}>
                We are a modern technology startup focused on building
                scalable digital products for businesses worldwide.
                Our team specializes in frontend development, backend
                engineering, and digital marketing strategies.
              </Typography>

              <Typography sx={{ color: "#555" }}>
                Our mission is to help companies grow using innovative
                technology solutions and user-focused design.
              </Typography>

            </Grid>

          </Grid>

          {/* Company Stats */}

          <Grid container spacing={4} sx={{ mt: 8, textAlign: "center" }}>

            <Grid item xs={12} md={4}>
              <Typography
                variant="h3"
                sx={{ fontWeight: "bold", color: "#1976d2" }}
              >
                10+
              </Typography>
              <Typography>Projects Completed</Typography>
            </Grid>

            <Grid item xs={12} md={4}>
              <Typography
                variant="h3"
                sx={{ fontWeight: "bold", color: "#1976d2" }}
              >
                1+
              </Typography>
              <Typography>Happy Clients</Typography>
            </Grid>

            <Grid item xs={12} md={4}>
              <Typography
                variant="h3"
                sx={{ fontWeight: "bold", color: "#1976d2" }}
              >
                1+
              </Typography>
              <Typography>Years Experience</Typography>
            </Grid>

          </Grid>

        </Container>
      </Box>

    </Box>
  );
}