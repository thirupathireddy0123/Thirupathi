import React, { useState, useEffect } from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  Button,
  Box,
  Container,
  IconButton,
  Menu,
  MenuItem,
  Drawer,
  List,
  ListItem,
  ListItemText,
  Switch,
  Grid
} from "@mui/material";

import MenuIcon from "@mui/icons-material/Menu";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";

import { motion } from "framer-motion";

export default function Navbar() {

  const [mobileOpen, setMobileOpen] = useState(false);
  const [megaMenu, setMegaMenu] = useState(null);
  const [darkMode, setDarkMode] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  /* Navbar shrink on scroll */

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };

    window.addEventListener("scroll", handleScroll);
  }, []);

  /* Smooth scroll */

  const scrollToSection = (id) => {
    const section = document.getElementById(id);

    if (section) {
      section.scrollIntoView({
        behavior: "smooth"
      });
    }

    setMobileOpen(false);
  };

  return (

    <motion.div
      initial={{ y: -80 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6 }}
    >

      <AppBar
        position="fixed"
        elevation={0}
        sx={{
          top: 20,
          left: "50%",
          transform: "translateX(-50%)",
          width: scrolled ? "80%" : "90%",
          borderRadius: "14px",
          backdropFilter: "blur(12px)",
          background: darkMode
            ? "rgba(20,20,20,0.85)"
            : "rgba(255,255,255,0.75)",
          color: darkMode ? "#fff" : "#000",
          transition: "0.4s"
        }}
      >

        <Container maxWidth="lg">

          <Toolbar sx={{ justifyContent: "space-between" }}>

            {/* Logo */}

            <Typography
              sx={{
                fontWeight: "bold",
                fontSize: "20px",
                cursor: "pointer"
              }}
              onClick={() => scrollToSection("home")}
            >
              MyStartup
            </Typography>

            {/* Desktop Menu */}

            <Box sx={{ display: { xs: "none", md: "flex" }, gap: 4 }}>

              <Button
                sx={menuStyle}
                onClick={() => scrollToSection("home")}
              >
                Home
              </Button>

              <Button
                sx={menuStyle}
                endIcon={<KeyboardArrowDownIcon />}
                onMouseEnter={(e) => setMegaMenu(e.currentTarget)}
              >
                Services
              </Button>

              <Button
                sx={menuStyle}
                onClick={() => scrollToSection("about")}
              >
                About
              </Button>

              <Button
                sx={menuStyle}
                onClick={() => scrollToSection("contact")}
              >
                Contact
              </Button>

            </Box>

            {/* Dark Mode */}

            <Switch
              checked={darkMode}
              onChange={() => setDarkMode(!darkMode)}
            />

            {/* CTA Button */}

            <Button
              sx={{
                background: "linear-gradient(45deg,#4facfe,#00f2fe)",
                color: "#fff",
                borderRadius: "20px",
                px: 3,
                textTransform: "none",
                boxShadow: "0 0 12px rgba(0,200,255,0.6)",
                "&:hover": {
                  boxShadow: "0 0 20px rgba(0,200,255,0.9)"
                }
              }}
            >
              Get Started
            </Button>

            {/* Mobile Menu */}

            <IconButton
              sx={{ display: { md: "none" } }}
              onClick={() => setMobileOpen(true)}
            >
              <MenuIcon />
            </IconButton>

          </Toolbar>

        </Container>

      </AppBar>

      {/* Mega Menu */}

      <Menu
        anchorEl={megaMenu}
        open={Boolean(megaMenu)}
        onClose={() => setMegaMenu(null)}
        MenuListProps={{
          onMouseLeave: () => setMegaMenu(null)
        }}
        PaperProps={{
          sx: {
            mt: 2,
            p: 3,
            width: 450
          }
        }}
      >

        <Grid container spacing={2}>

          <Grid item xs={6}>
            <MenuItem onClick={() => scrollToSection("services")}>
              Frontend Development
            </MenuItem>

            <MenuItem onClick={() => scrollToSection("services")}>
              React Applications
            </MenuItem>

            <MenuItem onClick={() => scrollToSection("services")}>
              UI/UX Design
            </MenuItem>
          </Grid>

          <Grid item xs={6}>
            <MenuItem onClick={() => scrollToSection("services")}>
              Backend Development
            </MenuItem>

            <MenuItem onClick={() => scrollToSection("services")}>
              API Development
            </MenuItem>

            <MenuItem onClick={() => scrollToSection("services")}>
              Cloud Solutions
            </MenuItem>
          </Grid>

        </Grid>

      </Menu>

      {/* Mobile Drawer */}

      <Drawer
        anchor="right"
        open={mobileOpen}
        onClose={() => setMobileOpen(false)}
      >

        <Box sx={{ width: 250 }}>

          <List>

            <ListItem button onClick={() => scrollToSection("home")}>
              <ListItemText primary="Home" />
            </ListItem>

            <ListItem button onClick={() => scrollToSection("services")}>
              <ListItemText primary="Services" />
            </ListItem>

            <ListItem button onClick={() => scrollToSection("about")}>
              <ListItemText primary="About" />
            </ListItem>

            <ListItem button onClick={() => scrollToSection("contact")}>
              <ListItemText primary="Contact" />
            </ListItem>

          </List>

        </Box>

      </Drawer>

    </motion.div>
  );
}

const menuStyle = {
  color: "inherit",
  fontWeight: 500,
  position: "relative",
  textTransform: "none",
  "&:after": {
    content: '""',
    position: "absolute",
    width: "0%",
    height: "2px",
    bottom: 0,
    left: 0,
    background: "#4facfe",
    transition: "0.3s"
  },
  "&:hover:after": {
    width: "100%"
  }
};