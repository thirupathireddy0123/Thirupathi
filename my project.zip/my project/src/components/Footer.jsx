import {
  Box,
  Container,
  Grid,
  Typography,
  IconButton
} from "@mui/material";

import FacebookIcon from "@mui/icons-material/Facebook";
import LinkedInIcon from "@mui/icons-material/LinkedIn";
import TwitterIcon from "@mui/icons-material/Twitter";
import InstagramIcon from "@mui/icons-material/Instagram";

export default function Footer() {
  return (
    <Box
      sx={{
        background: "#0f172a",
        color: "#fff",
        pt: 8,
        pb: 3,
        mt: 10
      }}
    >
      <Container maxWidth="lg">

        <Grid container spacing={4}>

          {/* Company Info */}
          <Grid item xs={12} md={4}>
            <Typography variant="h5" sx={{ fontWeight: "bold", mb: 2 }}>
              MyStartup
            </Typography>

            <Typography sx={{ color: "#cbd5e1" }}>
              We build modern digital products including
              frontend development, backend systems and
              digital marketing solutions for startups.
            </Typography>

            <Box sx={{ mt: 2 }}>

              <IconButton sx={{ color: "#fff" }}>
                <FacebookIcon />
              </IconButton>

              <IconButton sx={{ color: "#fff" }}>
                <LinkedInIcon />
              </IconButton>

              <IconButton sx={{ color: "#fff" }}>
                <TwitterIcon />
              </IconButton>

              <IconButton sx={{ color: "#fff" }}>
                <InstagramIcon />
              </IconButton>

            </Box>
          </Grid>

          {/* Services */}
          <Grid item xs={12} md={2}>
            <Typography variant="h6" sx={{ mb: 2 }}>
              Services
            </Typography>

            <Typography sx={linkStyle}>Frontend Development</Typography>
            <Typography sx={linkStyle}>Backend Development</Typography>
            <Typography sx={linkStyle}>Digital Marketing</Typography>
            <Typography sx={linkStyle}>UI/UX Design</Typography>
          </Grid>

          {/* Company */}
          <Grid item xs={12} md={2}>
            <Typography variant="h6" sx={{ mb: 2 }}>
              Company
            </Typography>

            <Typography sx={linkStyle}>About Us</Typography>
            <Typography sx={linkStyle}>Careers</Typography>
            <Typography sx={linkStyle}>Blog</Typography>
            <Typography sx={linkStyle}>Contact</Typography>
          </Grid>

          {/* Contact */}
          <Grid item xs={12} md={4}>
            <Typography variant="h6" sx={{ mb: 2 }}>
              Contact
            </Typography>

            <Typography sx={{ color: "#cbd5e1" }}>
              Hyderabad, India
            </Typography>

            <Typography sx={{ color: "#cbd5e1" }}>
              contact@mystartup.com
            </Typography>

            <Typography sx={{ color: "#cbd5e1" }}>
              +91 9876543210
            </Typography>
          </Grid>

        </Grid>

        {/* Bottom Line */}

        <Box
          sx={{
            borderTop: "1px solid #334155",
            mt: 6,
            pt: 3,
            textAlign: "center"
          }}
        >
          <Typography sx={{ color: "#94a3b8" }}>
            © 2026 MyStartup. All rights reserved.
          </Typography>
        </Box>

      </Container>
    </Box>
  );
}

const linkStyle = {
  color: "#cbd5e1",
  cursor: "pointer",
  mb: 1,
  "&:hover": {
    color: "#38bdf8"
  }
};